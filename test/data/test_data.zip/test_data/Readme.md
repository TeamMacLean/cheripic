## Readme for CHERIPIC test data

* Test data folder has following list of files
	1. input\_assembly_file.fa
	2. mutant\_bam_file.bam
	3. mutant\_pileup_file.pileup
	4. mutant\_vcf_file.vcf
	5. wildtype\_bam_file.bam
	6. wildtype\_pileup_file.pileup
	7. wildtype\_vcf_file.vcf

* `input_assembly_file.fa` as name suggests is the assembly file to use

* mutant and wild type bulks files start with `mutant_` and `wildtype_`, respectively, in their file names.

* We have provided pileup, vcf and bam files for mutant bulks and wild type bulks to be able to test using different bulk input options

* Example commands to use data in this folder

pileup inputs

```bash
./cheripic -f test_data/input_assembly_file.fa -a test_data/mutant_pileup_file.pileup -b test_data/wildtype_pileup_file.pileup
```			

vcf inputs

```bash
./cheripic -F vcf -f test_data/input_assembly_file.fa -a test_data/mutant_vcf_file.vcf -b test_data/wildtype_vcf_file.vcf 
```